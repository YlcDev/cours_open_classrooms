<?php

define('FS_METHOD', 'direct');



// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'db626566551');

/** MySQL database username */
define('DB_USER', 'dbo626566551');

/** MySQL database password */
define('DB_PASSWORD', 'iVeZVexOCgAcipapiefs');

/** MySQL hostname */
define('DB_HOST', 'db626566551.db.1and1.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'Ov>a(F1W8i7BN 3S)mYoj>V+4D{2_+O!jr,k<Rz|)h>&|[Ygldlu?]7GIK(?wZDq');
define('SECURE_AUTH_KEY',  '@pEzL3ay4_mf9w%$B[dm@An{u3zSs2,Mv&z K1y6Ki,}|eO3^=1HbLJEsG+|++!S');
define('LOGGED_IN_KEY',    '2+_;Jw.|VU+{rwlvA#XM$^:cwv#KV.YD^!_:I|C3-Qs-/P?}!>MlKEz=7^ueE-<u');
define('NONCE_KEY',        '[ +qF7I/:N(r+,+VEimy3B$ys*Dy@<s(W8,e?<`^RKcPYrJ-k}(XE|38^/er7SnK');
define('AUTH_SALT',        'yU-qb][K@G]+TI A u}X8s[|)wTt+Rlyb3WTRl+oI?(Wc&#.Bn-H:x1%c|y.y;XO');
define('SECURE_AUTH_SALT', 'l(9H>CgR~PE)UtCS}^NN Vu>5t7E8+&([pST1Cu=@9!0orACHxLd4(Q>Uikie>A#');
define('LOGGED_IN_SALT',   'Z1?DA4~qQP|`O-cM*_J&e#<h|IMcoke8_<5G{^(wuT~_WT*uuX71HsR-/_rlY^86');
define('NONCE_SALT',       'O&>.ZHa?L(mF}|[OI[yf`J%%jyDPB+ jAEbL1K3ZOUK/ntJPd]LcAiQ|rNF9XoaP');


$table_prefix = 'InOgXOjZ';





/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
